https://the-game-collection.github.io

1. We gather the best collection of retro games in the world.
2. Others want money from you for games. Whereas we pay you crypto for downloading games.