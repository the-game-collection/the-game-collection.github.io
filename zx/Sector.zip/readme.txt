https://the-game-collection.github.io

1. We gather the best collection of retro games in the world on our website.

   * Download about 10000 best retro games for free
   * Invite your friends and earn crypto with our affiliate program 
   * Exchange cryptos on the internal P2P market

2. But our "rom download manager" give you some additional options:

   * Resume broken downloads to keep you from losing the progress (important for big images)
   * Download games using our links and get 0.01 USDT for each downloaded gigabyte
   * Launch games and earn 0.01 USDT for every minute you play
