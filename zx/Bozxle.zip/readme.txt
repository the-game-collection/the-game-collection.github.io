https://the-game-collection.github.io

1. We gather the best collection of retro games in the world.

Download games from our web-site is free.

2. But our "rom download manager" give you some additional features:

- Resume broken downloads to keep you from losing the progress
- Change cryptocurrencies on the internal market
- Cryptocurrency withdrawal is available if you have more than 10 USDT in your account
- When you have more than 100 USDT in your account (VIP status):

	- You will get 0.01 USDT per Megabyte download
	- USDT miner will turns on and you will earn while you play