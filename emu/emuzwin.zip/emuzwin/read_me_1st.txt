Take in attantion, that the main Web page address was changed and KOL site is moved to
http://kol.thaddy.co.uk


